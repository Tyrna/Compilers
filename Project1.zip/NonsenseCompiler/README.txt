CS 5810 - Nonsense Compiler Project
By: Oscar Vanderhorst

-----
Run from command line like: "java NonsenseParser <inputfile>"
-----

Once run, it will print on console information about the translation.
It will also output the assembly code into a 'file.s' file.

This version of the compiler will NOT work properly for:

- Parenthesised expressions. (Register issues)
- Non-natural exponents.

Things to make better:

- Register management. Currently very forced for the sake of the assignment.
- Exponentiation function. Doesn't work with 0 and writes assembly at end of file.
